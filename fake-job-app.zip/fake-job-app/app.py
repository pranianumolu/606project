from flask import Flask, render_template, request
import joblib
from collections import Counter

app = Flask(__name__)

# Load model and vectorizer
model = joblib.load("fake_job_model.pkl")
vectorizer = joblib.load("vectorizer.pkl")

# Track predictions
prediction_counts = Counter({"Real": 0, "Fake": 0})

@app.route("/", methods=["GET", "POST"])
def home():
    prediction = None
    real_count = prediction_counts["Real"]
    fake_count = prediction_counts["Fake"]

    if request.method == "POST":
        title = request.form.get("title")
        description = request.form.get("description")
        text = f"{title} {description}"
        text_vec = vectorizer.transform([text])
        pred = model.predict(text_vec)[0]

        if pred == 0:
            prediction = "❌ Fake Job Posting"
            prediction_counts["Fake"] += 1
        else:
            prediction = "✅ Real Job Posting"
            prediction_counts["Real"] += 1

        real_count = prediction_counts["Real"]
        fake_count = prediction_counts["Fake"]

    return render_template("index.html", prediction=prediction,
                           real_count=real_count,
                           fake_count=fake_count)

if __name__ == "__main__":
    app.run(debug=True)
